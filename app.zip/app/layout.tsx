/**
 * Rôle du fichier : Structure commune de l'application : définit les métadonnées et enveloppe toutes les pages avec l'en-tête principal.
 */

import type { Metadata, Viewport } from "next";
import "./globals.css";
import "./desktop.css";
import { Inter, Poppins } from "next/font/google";

const inter = Inter({
  variable: "--font-inter",
  subsets: ["latin"],
});

const poppins = Poppins({
  variable: "--font-poppins",
  subsets: ["latin"],
  weight: ["500", "600", "700"],
});

export const metadata: Metadata = {
  title: "Steldra",
  description: "Films, séries, dramas et animés — votre univers cinéma STELDRA",
  manifest: "/manifest.webmanifest",
  appleWebApp: {
    capable: true,
    title: "STELDRA",
    statusBarStyle: "black-translucent",
  },
};

export const viewport: Viewport = {
  themeColor: "#030b12",
  viewportFit: "cover",
};

/** Applique la structure HTML commune à toutes les pages. */
export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html
      lang="fr"
      className={`${inter.variable} ${poppins.variable} h-full antialiased`}
    >
      <body className={`${inter.className} min-h-full flex flex-col`}>
        {children}

        <footer className="mt-auto text-center py-2">
        </footer>
      </body>
    </html>
  );
}