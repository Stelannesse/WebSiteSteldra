/**
 * Rôle du fichier : Page Tier Lists : permet de créer, réordonner, sauvegarder et partager des classements visuels.
 */

'use client';

import { useEffect, useMemo, useRef, useState } from 'react';
import { isCinemaType } from '../lib/cinemaScope';
import { useRouter } from 'next/navigation';
import MainNav from '../components/mainNav';
import { createClient } from '../lib/supabase';
import type { CustomList, CustomListItem, MediaItem, MyListItem, MediaType } from '../types/media';
import styles from './tierLists.module.css';

type TierRow = {
  id: string;
  label: string;
  title: string;
  media: MediaItem[];
};

type TierListData = {
  title: string;
  rows: TierRow[];
  unranked: MediaItem[];
};

type SavedTierList = TierListData & {
  id: string;
  createdAt: string;
  updatedAt: string;
};

type TierSourceList = {
  id: string;
  name: string;
  media: MediaItem[];
};

type CloudSyncStatus = 'loading' | 'ready' | 'offline' | 'setup-required';

type CloudTierListRecord = {
  id: string;
  title: string;
  rows: TierRow[];
  unranked: MediaItem[];
  created_at: string;
  updated_at: string;
};

const defaultRows: TierRow[] = [
  {
    id: 's',
    label: 'S',
    title: 'Exceptionnel',
    media: [],
  },
  {
    id: 'a',
    label: 'A',
    title: 'Excellent',
    media: [],
  },
  {
    id: 'b',
    label: 'B',
    title: 'Très bien',
    media: [],
  },
  {
    id: 'c',
    label: 'C',
    title: 'Moyen',
    media: [],
  },
  {
    id: 'd',
    label: 'D',
    title: 'Décevant',
    media: [],
  },
  {
    id: 'f',
    label: 'F',
    title: 'À éviter',
    media: [],
  },
];

const mediaLabels: Record<MediaType | 'tous', string> = {
  tous: 'Tout',
  movie: 'Films',
  tv: 'Séries',
  drama: 'Dramas',
  anime: 'Animés',
  manga: 'Mangas',
  manhwa: 'Manhwas',
};

/** Composant principal de cette page ou zone d'interface. */
export default function TierListsPage() {
  const router = useRouter();
  const [supabase] = useState(() => createClient());
  const tierListRef = useRef<HTMLDivElement | null>(null);
  const touchDraggedMediaRef = useRef<MediaItem | null>(null);
  const touchStartRef = useRef<{ x: number; y: number } | null>(null);
  const touchMovedRef = useRef(false);
  const coverRepairDoneRef = useRef(false);
  const suppressClickRef = useRef(false);

  const [title, setTitle] = useState('Ma Tier List');
  const [rows, setRows] = useState<TierRow[]>(defaultRows);
  const [unranked, setUnranked] = useState<MediaItem[]>([]);
  const [filter, setFilter] = useState<MediaType | 'tous'>('tous');
  const [search, setSearch] = useState('');
  const [draggedMedia, setDraggedMedia] = useState<MediaItem | null>(null);
  const [dragOverRank, setDragOverRank] = useState<string | null>(null);
  const [savedMessage, setSavedMessage] = useState('');
  const [touchDragging, setTouchDragging] = useState(false);
  const [savedTierLists, setSavedTierLists] = useState<SavedTierList[]>([]);
  const [activeSavedId, setActiveSavedId] = useState<string | null>(null);
  const [sourceLists, setSourceLists] = useState<TierSourceList[]>([]);
  const [activeSourceId, setActiveSourceId] = useState<'collection' | string>('collection');
  const [mobileOpenRowIds, setMobileOpenRowIds] = useState<Set<string>>(
    () => new Set([defaultRows[0].id])
  );
  const [mobileExpandedRowIds, setMobileExpandedRowIds] = useState<Set<string>>(
    () => new Set()
  );
  const [cloudSyncStatus, setCloudSyncStatus] = useState<CloudSyncStatus>('loading');

  useEffect(() => {
    const savedHistory = localStorage.getItem('steldra_saved_tier_lists_v1');

    if (savedHistory) {
      try {
        const parsedHistory: SavedTierList[] = JSON.parse(savedHistory);
        if (Array.isArray(parsedHistory)) {
          setSavedTierLists(parsedHistory);
        }
      } catch (error) {
        console.error('Historique des tier lists illisible :', error);
      }
    }

    const savedTierList = localStorage.getItem('steldra_tier_list_v1');

    if (savedTierList) {
      try {
        const parsed: TierListData = JSON.parse(savedTierList);

        setTitle(parsed.title || 'Ma Tier List');
        setRows(parsed.rows?.length ? parsed.rows : defaultRows);
        setUnranked(parsed.unranked || []);
        return;
      } catch (error) {
        console.error('Tier list illisible :', error);
      }
    }

    const savedCollection = localStorage.getItem(
      'steldra_multimedia_list_v1'
    );

    if (!savedCollection) return;

    try {
      const parsedCollection: {
        [key: string]: MyListItem;
      } = JSON.parse(savedCollection);

      const collectionMedia = Object.values(parsedCollection).filter((entry) => isCinemaType(entry?.media?.type)).map(
        (entry) => entry.media
      );

      setUnranked(collectionMedia);
    } catch (error) {
      console.error('Collection illisible :', error);
    }
  }, []);

  useEffect(() => {
    const loadCloudTierLists = async () => {
      try {
        const { data: { user } } = await supabase.auth.getUser();

        if (!user) {
          setCloudSyncStatus('offline');
          return;
        }

        const { data, error } = await supabase
          .from('tier_lists')
          .select('id,title,rows,unranked,created_at,updated_at')
          .eq('user_id', user.id)
          .order('updated_at', { ascending: false });

        if (error) {
          setCloudSyncStatus(['42P01', 'PGRST205'].includes(error.code) ? 'setup-required' : 'offline');
          console.error('Synchronisation des tier lists indisponible :', error);
          return;
        }

        const localHistory = localStorage.getItem('steldra_saved_tier_lists_v1');
        const localTierLists: SavedTierList[] = localHistory
          ? JSON.parse(localHistory)
          : [];
        const cloudTierLists: SavedTierList[] = ((data || []) as CloudTierListRecord[]).map((item) => ({
          id: item.id,
          title: item.title,
          rows: item.rows,
          unranked: item.unranked,
          createdAt: item.created_at,
          updatedAt: item.updated_at,
        }));
        const merged = new Map<string, SavedTierList>();

        [...cloudTierLists, ...localTierLists].forEach((item) => {
          const current = merged.get(item.id);
          if (!current || new Date(item.updatedAt).getTime() > new Date(current.updatedAt).getTime()) {
            merged.set(item.id, item);
          }
        });

        const synchronizedTierLists = Array.from(merged.values()).sort(
          (a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime()
        );

        setSavedTierLists(synchronizedTierLists);
        localStorage.setItem('steldra_saved_tier_lists_v1', JSON.stringify(synchronizedTierLists));

        if (synchronizedTierLists.length > 0) {
          const { error: migrationError } = await supabase.from('tier_lists').upsert(
            synchronizedTierLists.map((item) => ({
              id: item.id,
              user_id: user.id,
              title: item.title,
              rows: item.rows,
              unranked: item.unranked,
              created_at: item.createdAt,
              updated_at: item.updatedAt,
            })),
            { onConflict: 'id' }
          );

          if (migrationError) {
            throw migrationError;
          }
        }

        setCloudSyncStatus('ready');
      } catch (error) {
        console.error('Erreur pendant la synchronisation des tier lists :', error);
        setCloudSyncStatus('offline');
      }
    };

    void loadCloudTierLists();
  }, [supabase]);

  useEffect(() => {
    const loadCustomLists = async () => {
      try {
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) return;

        const { data: listData, error: listError } = await supabase
          .from('custom_lists')
          .select('*')
          .eq('user_id', user.id)
          .order('created_at', { ascending: false });

        if (listError || !listData?.length) {
          if (listError) console.error('Impossible de charger les listes :', listError);
          setSourceLists([]);
          return;
        }

        const lists = listData as CustomList[];
        const listIds = lists.map((list) => list.id);
        const { data: itemData, error: itemError } = await supabase
          .from('custom_list_items')
          .select('*').in('media_type', ['movie', 'tv', 'drama', 'anime'])
          .in('list_id', listIds)
          .order('position', { ascending: true });

        if (itemError) {
          console.error('Impossible de charger le contenu des listes :', itemError);
          return;
        }

        const grouped = new Map<string, MediaItem[]>();
        ((itemData || []) as CustomListItem[]).forEach((item) => {
          if (!item.media_data) return;
          const current = grouped.get(item.list_id) || [];
          current.push(item.media_data);
          grouped.set(item.list_id, current);
        });

        coverRepairDoneRef.current = false;
        setSourceLists(
          lists.map((list) => ({
            id: list.id,
            name: list.name,
            media: grouped.get(list.id) || [],
          }))
        );
      } catch (error) {
        console.error('Erreur de chargement des listes :', error);
      }
    };

    void loadCustomLists();
  }, [supabase]);

  useEffect(() => {
    if (coverRepairDoneRef.current) return;

    const allMedia = [
      ...unranked,
      ...rows.flatMap((row) => row.media),
      ...sourceLists.flatMap((list) => list.media),
    ];

    if (allMedia.length === 0) return;

    const missingCovers = Array.from(
      new Map(
        allMedia
          .filter(
            (media) =>
              isCinemaType(media.type) &&
              !media.poster_path
          )
          .map((media) => [`${media.type}_${media.id}`, media])
      ).values()
    );

    coverRepairDoneRef.current = true;
    if (missingCovers.length === 0) return;

    const repairCovers = async () => {
      const repaired = new Map<string, string>();

      await Promise.allSettled(
        missingCovers.map(async (media) => {
          const response = await fetch(
            `/api/media-details?id=${encodeURIComponent(String(media.id))}&type=${encodeURIComponent(media.type)}`
          );

          if (!response.ok) return;

          const data = await response.json();
          if (typeof data.poster_path === 'string' && data.poster_path) {
            repaired.set(`${media.type}_${media.id}`, data.poster_path);
          }
        })
      );

      if (repaired.size === 0) return;

      const applyPoster = (media: MediaItem): MediaItem => {
        const poster = repaired.get(`${media.type}_${media.id}`);
        return poster ? { ...media, poster_path: poster } : media;
      };

      setUnranked((current) => current.map(applyPoster));
      setRows((currentRows) =>
        currentRows.map((row) => ({
          ...row,
          media: row.media.map(applyPoster),
        }))
      );
      setSourceLists((currentLists) =>
        currentLists.map((list) => ({
          ...list,
          media: list.media.map(applyPoster),
        }))
      );
    };

    void repairCovers();
  }, [rows, unranked, sourceLists]);

  const filteredUnranked = useMemo(() => {
    const rankedKeys = new Set(
      rows.flatMap((row) =>
        row.media.map((media) => `${media.type}_${media.id}`)
      )
    );

    const sourceMedia =
      activeSourceId === 'collection'
        ? unranked
        : sourceLists.find((list) => list.id === activeSourceId)?.media || [];

    return sourceMedia.filter((media) => isCinemaType(media.type)).filter((media) => {
      const mediaKey = `${media.type}_${media.id}`;
      const matchesType = filter === 'tous' || media.type === filter;
      const matchesSearch = media.title
        .toLowerCase()
        .includes(search.trim().toLowerCase());

      return !rankedKeys.has(mediaKey) && matchesType && matchesSearch;
    });
  }, [unranked, rows, sourceLists, activeSourceId, filter, search]);

  const removeMediaEverywhere = (media: MediaItem) => {
    const mediaKey = `${media.type}_${media.id}`;

    setRows((currentRows) =>
      currentRows.map((row) => ({
        ...row,
        media: row.media.filter(
          (item) => `${item.type}_${item.id}` !== mediaKey
        ),
      }))
    );

    setUnranked((current) =>
      current.filter(
        (item) => `${item.type}_${item.id}` !== mediaKey
      )
    );
  };

  const moveToRow = (media: MediaItem, rowId: string) => {
    removeMediaEverywhere(media);

    setRows((currentRows) =>
      currentRows.map((row) =>
        row.id === rowId
          ? {
              ...row,
              media: [...row.media, media],
            }
          : row
      )
    );
  };

  const moveToUnranked = (media: MediaItem) => {
    removeMediaEverywhere(media);

    setUnranked((current) => [...current, media]);
  };

  const handlePointerDown = (
    event: React.PointerEvent<HTMLButtonElement>,
    media: MediaItem
  ) => {
    event.currentTarget.setPointerCapture(event.pointerId);
    touchDraggedMediaRef.current = media;
    touchStartRef.current = { x: event.clientX, y: event.clientY };
    touchMovedRef.current = false;
    setDraggedMedia(media);
  };

  const handlePointerMove = (
    event: React.PointerEvent<HTMLButtonElement>
  ) => {
    if (!touchDraggedMediaRef.current) return;

    const start = touchStartRef.current;
    if (start) {
      const distance = Math.hypot(
        event.clientX - start.x,
        event.clientY - start.y
      );

      if (distance > 6) {
        touchMovedRef.current = true;
        setTouchDragging(true);
      }
    }

    if (!touchMovedRef.current) return;
    event.preventDefault();

    const edgeZone = 90;
    if (event.clientY < edgeZone) {
      window.scrollBy({ top: -22, behavior: 'auto' });
    } else if (event.clientY > window.innerHeight - edgeZone) {
      window.scrollBy({ top: 22, behavior: 'auto' });
    }

    const target = document.elementFromPoint(
      event.clientX,
      event.clientY
    ) as HTMLElement | null;

    const rowTarget = target?.closest<HTMLElement>('[data-tier-row-id]');
    const isUnranked = Boolean(
      target?.closest<HTMLElement>('[data-tier-unranked]')
    );

    if (rowTarget?.dataset.tierRowId) {
      setDragOverRank(rowTarget.dataset.tierRowId);
    } else if (isUnranked) {
      setDragOverRank('unranked');
    } else {
      setDragOverRank(null);
    }
  };

  const finishPointerDrag = (event: React.PointerEvent<HTMLButtonElement>) => {
    const media = touchDraggedMediaRef.current;
    if (!media) return;

    if (touchMovedRef.current) {
      suppressClickRef.current = true;
      window.setTimeout(() => {
        suppressClickRef.current = false;
      }, 250);

      const target = document.elementFromPoint(
        event.clientX,
        event.clientY
      ) as HTMLElement | null;

      const rowTarget = target?.closest<HTMLElement>('[data-tier-row-id]');
      const isUnranked = Boolean(
        target?.closest<HTMLElement>('[data-tier-unranked]')
      );

      if (rowTarget?.dataset.tierRowId) {
        moveToRow(media, rowTarget.dataset.tierRowId);
      } else if (isUnranked) {
        moveToUnranked(media);
      }
    }

    touchDraggedMediaRef.current = null;
    touchStartRef.current = null;
    touchMovedRef.current = false;
    setDraggedMedia(null);
    setDragOverRank(null);
    setTouchDragging(false);
  };

  const handlePointerUp = (
    event: React.PointerEvent<HTMLButtonElement>
  ) => {
    finishPointerDrag(event);
  };

  const handlePointerCancel = () => {
    touchDraggedMediaRef.current = null;
    touchStartRef.current = null;
    touchMovedRef.current = false;
    setDraggedMedia(null);
    setDragOverRank(null);
    setTouchDragging(false);
  };

  const updateRowTitle = (rowId: string, value: string) => {
    setRows((currentRows) =>
      currentRows.map((row) =>
        row.id === rowId
          ? {
              ...row,
              title: value,
            }
          : row
      )
    );
  };

  const updateRowLabel = (
  rowId: string,
  value: string
) => {
  setRows((currentRows) =>
    currentRows.map((row) =>
      row.id === rowId
        ? {
            ...row,
            label: value.toUpperCase().slice(0, 3),
          }
        : row
    )
  );
};

/** Ajoute un nouveau rang disponible à la tier list. */
const addRow = () => {
  const usedLabels = rows.map((row) =>
    row.label.toUpperCase()
  );

  const availableLabels = [
    'S',
    'A',
    'B',
    'C',
    'D',
    'E',
    'F',
    'G',
    'H',
  ];

  const nextLabel =
    availableLabels.find(
      (label) => !usedLabels.includes(label)
    ) ?? `R${rows.length + 1}`;

  const newRow: TierRow = {
    id:
      typeof crypto !== 'undefined' &&
      crypto.randomUUID
        ? crypto.randomUUID()
        : `row-${Date.now()}`,
    label: nextLabel,
    title: 'Nouveau rang',
    media: [],
  };

  setRows((currentRows) => [
    ...currentRows,
    newRow,
  ]);
};

/** Supprime un rang après confirmation et replace ses médias parmi les éléments non classés. */
const deleteRow = (rowId: string) => {
  const rowToDelete = rows.find(
    (row) => row.id === rowId
  );

  if (!rowToDelete) return;

  const confirmed = window.confirm(
    `Supprimer le rang ${rowToDelete.label} ?`
  );

  if (!confirmed) return;

  setUnranked((currentMedia) => {
    const allMedia = [
      ...currentMedia,
      ...rowToDelete.media,
    ];

    return Array.from(
      new Map(
        allMedia.map((media) => [
          `${media.type}_${media.id}`,
          media,
        ])
      ).values()
    );
  });

  setRows((currentRows) =>
    currentRows.filter(
      (row) => row.id !== rowId
    )
  );

  setDragOverRank(null);
};

  const openMedia = (media: MediaItem) => {
    sessionStorage.setItem(
      'steldra_selected_media',
      JSON.stringify(media)
    );

    router.push(`/media/${media.type}/${media.id}`);
  };

  const syncTierListToCloud = async (snapshot: SavedTierList) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        setCloudSyncStatus('offline');
        return;
      }

      const { error } = await supabase.from('tier_lists').upsert({
        id: snapshot.id,
        user_id: user.id,
        title: snapshot.title,
        rows: snapshot.rows,
        unranked: snapshot.unranked,
        created_at: snapshot.createdAt,
        updated_at: snapshot.updatedAt,
      }, { onConflict: 'id' });

      if (error) {
        setCloudSyncStatus(['42P01', 'PGRST205'].includes(error.code) ? 'setup-required' : 'offline');
        console.error('Tier list enregistrée localement, mais pas en ligne :', error);
        return;
      }

      setCloudSyncStatus('ready');
      setSavedMessage('Tier list synchronisée sur tous vos appareils');
    } catch (error) {
      console.error('Tier list enregistrée localement, mais pas en ligne :', error);
      setCloudSyncStatus('offline');
    }
  };

  const deleteTierListFromCloud = async (tierListId: string) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { error } = await supabase
        .from('tier_lists')
        .delete()
        .eq('id', tierListId)
        .eq('user_id', user.id);

      if (error) {
        setCloudSyncStatus(['42P01', 'PGRST205'].includes(error.code) ? 'setup-required' : 'offline');
        console.error('Suppression en ligne impossible :', error);
      }
    } catch (error) {
      console.error('Suppression en ligne impossible :', error);
    }
  };

  const persistTierList = (message = 'Tier list enregistrée') => {
    const now = new Date().toISOString();
    const data: TierListData = { title, rows, unranked };

    localStorage.setItem(
      'steldra_tier_list_v1',
      JSON.stringify(data)
    );

    const savedId = activeSavedId || (
      typeof crypto !== 'undefined' && crypto.randomUUID
        ? crypto.randomUUID()
        : `tier-${Date.now()}`
    );
    const existing = savedTierLists.find((item) => item.id === savedId);
    const snapshot: SavedTierList = {
      ...data,
      id: savedId,
      createdAt: existing?.createdAt || now,
      updatedAt: now,
    };
    const next = existing
      ? savedTierLists.map((item) => item.id === savedId ? snapshot : item)
      : [snapshot, ...savedTierLists];

    next.sort(
      (a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime()
    );
    setSavedTierLists(next);
    localStorage.setItem('steldra_saved_tier_lists_v1', JSON.stringify(next));
    void syncTierListToCloud(snapshot);

    setActiveSavedId(savedId);
    setSavedMessage(message);

    window.setTimeout(() => {
      setSavedMessage('');
    }, 2200);

    return snapshot.id;
  };

  const saveTierList = () => {
    persistTierList('Tier list enregistrée');
  };

  const editSavedTierList = (saved: SavedTierList) => {
    setTitle(saved.title || 'Ma Tier List');
    setRows(saved.rows?.length ? saved.rows : defaultRows);
    setUnranked(saved.unranked || []);
    setActiveSavedId(saved.id);
    setSavedMessage('Tier list chargée — tu peux la modifier');

    window.setTimeout(() => {
      setSavedMessage('');
    }, 2200);

    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const deleteSavedTierList = (saved: SavedTierList) => {
    if (!window.confirm(`Supprimer « ${saved.title || 'Tier list'} » ?`)) {
      return;
    }

    setSavedTierLists((current) => {
      const next = current.filter((item) => item.id !== saved.id);
      localStorage.setItem(
        'steldra_saved_tier_lists_v1',
        JSON.stringify(next)
      );
      return next;
    });

    if (activeSavedId === saved.id) {
      setActiveSavedId(null);
    }

    void deleteTierListFromCloud(saved.id);
  };

  const resetTierList = () => {
    const allMedia = [
      ...unranked,
      ...rows.flatMap((row) => row.media),
    ];

    const uniqueMedia = Array.from(
      new Map(
        allMedia.map((media) => [
          `${media.type}_${media.id}`,
          media,
        ])
      ).values()
    );

    setRows(defaultRows);
    setUnranked(uniqueMedia);
    setTitle('Ma Tier List');
    setActiveSavedId(null);
  };

  const createMobileTierListBlob = async (statusWindow: Window | null) => {
    const canvas = document.createElement('canvas');
    const context = canvas.getContext('2d');
    if (!context) throw new Error('Canvas indisponible');

    // Format compact identique à l'ancienne tier list téléchargée : rangs
    // horizontaux, petites affiches et beaucoup de médias sur une ligne.
    const width = 1200;
    const posterWidth = 46;
    const posterHeight = 69;
    const posterGap = 7;
    const columns = 19;
    const contentStartX = 116;
    const rowHeights = rows.map((row) => {
      const lines = Math.max(1, Math.ceil(row.media.filter((media) => isCinemaType(media.type)).length / columns));
      return 38 + lines * (posterHeight + posterGap) + 12;
    });
    const height = 104 + rowHeights.reduce((total, rowHeight) => total + rowHeight, 0) + 38;
    const rankColors = [
      '#ff5565', '#ff9a4d', '#ffd84a', '#52d66f',
      '#4ca9f5', '#a54be7', '#f472b6', '#22d3ee',
    ];

    canvas.width = width;
    canvas.height = height;
    context.fillStyle = '#07121c';
    context.fillRect(0, 0, width, height);
    context.fillStyle = '#f4fafc';
    context.font = '800 32px system-ui, sans-serif';
    context.fillText(title || 'Ma Tier List', 28, 52);
    context.fillStyle = '#77a0b1';
    context.font = '600 16px system-ui, sans-serif';
    context.fillText(`${rows.reduce((total, row) => total + row.media.filter((media) => isCinemaType(media.type)).length, 0)} médias classés`, 30, 78);

    const loadPoster = (source: string) => new Promise<HTMLImageElement | null>((resolve) => {
      const image = new Image();
      const timeout = window.setTimeout(() => resolve(null), 6_000);
      image.onload = () => {
        window.clearTimeout(timeout);
        resolve(image);
      };
      image.onerror = () => {
        window.clearTimeout(timeout);
        resolve(null);
      };
      image.src = source;
    });

    let y = 104;

    for (let rowIndex = 0; rowIndex < rows.length; rowIndex += 1) {
      const row = rows[rowIndex];
      const sectionHeight = rowHeights[rowIndex];

      if (statusWindow) {
        statusWindow.document.body.textContent =
          `Préparation du rang ${row.title || row.label} (${rowIndex + 1}/${rows.length})…`;
      }

      context.fillStyle = '#0c1b27';
      context.fillRect(24, y, width - 48, sectionHeight - 8);
      context.fillStyle = rankColors[rowIndex % rankColors.length];
      context.fillRect(24, y, 76, sectionHeight - 8);
      context.fillStyle = '#101820';
      context.font = '900 23px system-ui, sans-serif';
      context.textAlign = 'center';
      context.fillText(row.label, 62, y + 31);
      context.textAlign = 'left';
      context.fillStyle = '#f2f8fa';
      context.font = '800 17px system-ui, sans-serif';
      context.fillText(row.title || `Rang ${row.label}`, contentStartX, y + 24);
      context.fillStyle = '#8ba5b0';
      context.font = '700 14px system-ui, sans-serif';
      context.fillText(`${row.media.filter((media) => isCinemaType(media.type)).length} média${row.media.filter((media) => isCinemaType(media.type)).length > 1 ? 's' : ''}`, width - 118, y + 23);

      const loadingBatchSize = 16;
      for (let mediaStart = 0; mediaStart < row.media.filter((media) => isCinemaType(media.type)).length; mediaStart += loadingBatchSize) {
        const mediaBatch = row.media.filter((media) => isCinemaType(media.type)).slice(mediaStart, mediaStart + loadingBatchSize);
        const loadedPosters = await Promise.all(
          mediaBatch.map((media) => loadPoster(getPosterUrl(media)))
        );

        loadedPosters.forEach((poster, batchIndex) => {
          const mediaIndex = mediaStart + batchIndex;
          const column = mediaIndex % columns;
          const line = Math.floor(mediaIndex / columns);
          const posterX = contentStartX + column * (posterWidth + posterGap);
          const posterY = y + 35 + line * (posterHeight + posterGap);

          context.fillStyle = '#132633';
          context.fillRect(posterX, posterY, posterWidth, posterHeight);
          if (poster) {
            context.drawImage(poster, posterX, posterY, posterWidth, posterHeight);
          }
          context.strokeStyle = 'rgba(115, 190, 211, .35)';
          context.lineWidth = 2;
          context.strokeRect(posterX, posterY, posterWidth, posterHeight);
        });
      }

      y += sectionHeight;
    }

    return new Promise<Blob>((resolve, reject) => {
      canvas.toBlob(
        (blob) => blob ? resolve(blob) : reject(new Error('Image mobile vide')),
        'image/jpeg',
        0.9
      );
    });
  };

  const showMobileTierListExport = (
    exportBlob: Blob,
    exportTitle: string,
    previewWindow: Window
  ) => {
    const objectUrl = URL.createObjectURL(exportBlob);
    const fileName = `${exportTitle.trim().toLowerCase().replaceAll(' ', '-') || 'tier-list'}.jpg`;
    const previewDocument = previewWindow.document;
    previewDocument.body.textContent = '';
    previewDocument.body.style.cssText =
      'margin:0;min-height:100vh;background:#07121c;color:#fff;font-family:system-ui;text-align:center;padding:18px;box-sizing:border-box;';

    const instruction = previewDocument.createElement('p');
    instruction.textContent = 'Touchez « Enregistrer », puis utilisez Partager si Safari ouvre simplement l’image.';
    instruction.style.cssText = 'max-width:520px;margin:0 auto 14px;color:#c8d6df;font-size:15px;';

    const downloadLink = previewDocument.createElement('a');
    downloadLink.href = objectUrl;
    downloadLink.download = fileName;
    downloadLink.textContent = 'Enregistrer la Tier List';
    downloadLink.style.cssText =
      'display:inline-block;margin-bottom:18px;padding:13px 18px;border-radius:12px;background:#078ee8;color:#fff;text-decoration:none;font-weight:800;';

    const previewImage = previewDocument.createElement('img');
    previewImage.src = objectUrl;
    previewImage.alt = exportTitle;
    previewImage.style.cssText = 'display:block;width:100%;height:auto;margin:0 auto;border-radius:10px;';
    previewDocument.body.append(instruction, downloadLink, previewImage);
  };

  const captureTierList = async (
    exportTitle: string,
    preparedMobileWindow: Window | null = null
  ) => {
    const exportNode = tierListRef.current;
    if (!exportNode) return;

    const isMobileExport = window.matchMedia('(max-width: 760px)').matches;
    const mobilePreviewWindow = isMobileExport
      ? preparedMobileWindow || window.open('', '_blank')
      : null;
    const posterImages = Array.from(exportNode.querySelectorAll<HTMLImageElement>('img'));
    const originalImageSources = posterImages.map((image) => image.src);

    if (mobilePreviewWindow) {
      mobilePreviewWindow.document.title = 'Préparation de la Tier List';
      mobilePreviewWindow.document.body.style.cssText =
        'margin:0;min-height:100vh;display:grid;place-items:center;background:#07121c;color:#fff;font-family:system-ui;text-align:center;padding:24px;';
      mobilePreviewWindow.document.body.textContent = 'Préparation de votre Tier List…';
    }

    try {
      if (isMobileExport && mobilePreviewWindow) {
        const mobileBlob = await createMobileTierListBlob(mobilePreviewWindow);
        showMobileTierListExport(mobileBlob, exportTitle, mobilePreviewWindow);
        return;
      }

      const htmlToImage = await import('html-to-image');

      // Sur mobile, html-to-image peut sinon se limiter aux dimensions
      // visibles du bloc. On passe brièvement en mode export : largeur
      // stable + rangs entièrement dépliés, puis on capture le scrollHeight.
      exportNode.dataset.exporting = 'true';

      // Chaque affiche est convertie séparément en image locale avant la
      // capture. Cela évite qu'un navigateur réutilise la même affiche pour
      // plusieurs médias lorsqu'une longue tier list est exportée.
      for (let index = 0; index < posterImages.length; index += 6) {
        const batch = posterImages.slice(index, index + 6);

        await Promise.all(batch.map(async (image) => {
          try {
            const response = await fetch(image.currentSrc || image.src, { cache: 'force-cache' });
            if (!response.ok) return;

            const blob = await response.blob();
            const localSource = await new Promise<string>((resolve, reject) => {
              const reader = new FileReader();
              reader.onload = () => resolve(String(reader.result));
              reader.onerror = () => reject(reader.error);
              reader.readAsDataURL(blob);
            });

            image.src = localSource;
            await image.decode().catch(() => undefined);
          } catch (error) {
            console.warn('Affiche conservée dans son format original :', error);
          }
        }));
      }

      await new Promise<void>((resolve) => {
        requestAnimationFrame(() =>
          requestAnimationFrame(() => resolve())
        );
      });

      const exportWidth = Math.ceil(exportNode.scrollWidth);
      const exportHeight = Math.ceil(exportNode.scrollHeight);

      const exportBlob = await htmlToImage.toBlob(exportNode, {
        cacheBust: false,
        pixelRatio: isMobileExport ? 1 : 1.5,
        backgroundColor: '#101720',
        width: exportWidth,
        height: exportHeight,
        style: {
          width: `${exportWidth}px`,
          height: `${exportHeight}px`,
          maxWidth: 'none',
          maxHeight: 'none',
          overflow: 'visible',
        },
      });

      if (!exportBlob) {
        throw new Error('Image exportée vide');
      }

      const objectUrl = URL.createObjectURL(exportBlob);
      const fileName = `${exportTitle
        .trim()
        .toLowerCase()
        .replaceAll(' ', '-') || 'tier-list'}.png`;

      if (!mobilePreviewWindow) {
        const link = document.createElement('a');
        link.download = fileName;
        link.href = objectUrl;
        document.body.appendChild(link);
        link.click();
        link.remove();
        window.setTimeout(() => URL.revokeObjectURL(objectUrl), 60_000);
      }
    } catch (error) {
      console.error(
        'Erreur pendant le téléchargement :',
        error
      );

      alert(
        "Le téléchargement n'a pas pu être effectué."
      );
      if (mobilePreviewWindow) {
        mobilePreviewWindow.document.body.textContent =
          "La création de l'image a échoué. Revenez à Steldra et réessayez.";
      }
    } finally {
      posterImages.forEach((image, index) => {
        image.src = originalImageSources[index];
      });

      if (exportNode) {
        delete exportNode.dataset.exporting;
      }
    }
  };

  const downloadTierList = async () => {
    persistTierList('Tier list enregistrée et téléchargée');
    await captureTierList(title);
  };

  const downloadSavedTierList = (saved: SavedTierList) => {
    const preparedMobileWindow = window.matchMedia('(max-width: 760px)').matches
      ? window.open('', '_blank')
      : null;
    const previous = {
      title,
      rows,
      unranked,
      activeSavedId,
    };

    setTitle(saved.title || 'Ma Tier List');
    setRows(saved.rows?.length ? saved.rows : defaultRows);
    setUnranked(saved.unranked || []);
    setActiveSavedId(saved.id);

    window.setTimeout(async () => {
      await captureTierList(saved.title || 'Tier List', preparedMobileWindow);

      setTitle(previous.title);
      setRows(previous.rows);
      setUnranked(previous.unranked);
      setActiveSavedId(previous.activeSavedId);
    }, 120);
  };

  const rankedMediaCount = rows.reduce((total, row) => total + row.media.filter((media) => isCinemaType(media.type)).length, 0);
  const activeSourceMediaCount = activeSourceId === 'collection'
    ? unranked.filter((media) => isCinemaType(media.type)).length + rows.flatMap((row) => row.media).filter((media) =>
        unranked.some((item) => item.type === media.type && String(item.id) === String(media.id))
      ).length
    : sourceLists.find((list) => list.id === activeSourceId)?.media.length || 0;

  const getPosterUrl = (media: MediaItem) => {
    if (!media.poster_path) {
      return '/steldra-poster-placeholder.svg';
    }

    const remoteUrl = media.poster_path.startsWith('http')
      ? media.poster_path
      : `https://image.tmdb.org/t/p/w342${media.poster_path}`;

    return `/api/poster-proxy?url=${encodeURIComponent(remoteUrl)}`;
  };

  const toggleMobileRow = (rowId: string) => {
    setMobileOpenRowIds((current) => {
      const next = new Set(current);

      if (next.has(rowId)) {
        next.delete(rowId);
      } else {
        next.add(rowId);
      }

      return next;
    });
  };

  const toggleMobileRowExpansion = (rowId: string) => {
    setMobileExpandedRowIds((current) => {
      const next = new Set(current);

      if (next.has(rowId)) {
        next.delete(rowId);
      } else {
        next.add(rowId);
      }

      return next;
    });
  };

  const scrollToRow = (rowId: string) => {
    setMobileOpenRowIds((current) => new Set(current).add(rowId));
    document.getElementById(`tier-row-${rowId}`)?.scrollIntoView({
      behavior: 'smooth',
      block: 'start',
    });
  };

  return (
    <>
      <MainNav />

      <main data-steldra-ui="page touchDragging" className={`${styles.page} ${touchDragging ? styles.touchDragging : ''}`}>
        <section data-steldra-ui="heroPanel" className={styles.heroPanel}>
          <div data-steldra-ui="tierHero" className={styles.tierHero}>
            <div data-steldra-ui="tierHeroGlow" className={styles.tierHeroGlow} aria-hidden="true" />
            <div data-steldra-ui="pageHeader" className={styles.pageHeader}>
              <div>
                <span data-steldra-ui="heroEyebrow" className={styles.heroEyebrow}>VOTRE CLASSEMENT</span>
                <h1>Tier Lists</h1>
                <p data-steldra-ui="heroTagline" className={styles.heroTagline}>Classez et sauvegardez tous vos favoris.</p>
              </div>

              <div data-steldra-ui="heroStats" className={styles.heroStats}>
                <div><strong>{rankedMediaCount}</strong><span>classés</span></div>
                <div><strong>{rows.length}</strong><span>rangs</span></div>
                <div><strong>{savedTierLists.length}</strong><span>sauvegardes</span></div>
              </div>
            </div>
          </div>

          <div data-steldra-ui="libraryDeck" className={styles.libraryDeck}>
            <div data-steldra-ui="libraryDeckHeader" className={styles.libraryDeckHeader}>
              <div>
                <span data-steldra-ui="deckEyebrow" className={styles.deckEyebrow}>RÉSERVE</span>
                <h2>Choisissez les médias à classer</h2>
              </div>
              <span>{filteredUnranked.length} disponible{filteredUnranked.length > 1 ? 's' : ''}</span>
            </div>

            <div data-steldra-ui="filters" className={styles.filters}>
              <input
                type="search"
                value={search}
                onChange={(event) => setSearch(event.target.value)}
                placeholder="⌕  Rechercher un média..."
                data-steldra-ui="searchInput" className={styles.searchInput}
              />

              <div data-steldra-ui="typeFilters" className={styles.typeFilters}>
                {(Object.keys(mediaLabels) as Array<MediaType | 'tous'>).filter((type) => type === 'tous' || isCinemaType(type)).map((type) => (
                  <button
                    key={type}
                    type="button"
                    data-steldra-ui="filterButton filterButtonActive" className={`${styles.filterButton} ${filter === type ? styles.filterButtonActive : ''}`}
                    onClick={() => setFilter(type)}
                  >
                    {type === 'tous' ? 'Tous' : mediaLabels[type]}
                  </button>
                ))}
              </div>
            </div>

            <div data-steldra-ui="sourcePicker" className={styles.sourcePicker}>
              <button
                type="button"
                data-steldra-ui="sourceButton sourceButtonActive" className={`${styles.sourceButton} ${activeSourceId === 'collection' ? styles.sourceButtonActive : ''}`}
                onClick={() => setActiveSourceId('collection')}
              >
                Ma collection
              </button>

              {sourceLists.map((list) => (
                <button
                  key={list.id}
                  type="button"
                  data-steldra-ui="sourceButton sourceButtonActive" className={`${styles.sourceButton} ${activeSourceId === list.id ? styles.sourceButtonActive : ''}`}
                  onClick={() => setActiveSourceId(list.id)}
                >
                  {list.name}
                  <span>{list.media.length}</span>
                </button>
              ))}
            </div>

            <div
              data-tier-unranked
              data-steldra-ui="unrankedGrid unrankedDragOver" className={`${styles.unrankedGrid} ${dragOverRank === 'unranked' ? styles.unrankedDragOver : ''}`}
            >
              {filteredUnranked.map((media) => (
                <button
                  key={`${media.type}_${media.id}`}
                  type="button"
                  data-steldra-ui="libraryPoster" className={styles.libraryPoster}
                  onPointerDown={(event) => handlePointerDown(event, media)}
                  onPointerMove={handlePointerMove}
                  onPointerUp={handlePointerUp}
                  onPointerCancel={handlePointerCancel}
                  onClick={(event) => {
                    if (suppressClickRef.current) {
                      event.preventDefault();
                      return;
                    }
                    openMedia(media);
                  }}
                  title={`${media.title} — ouvrir la fiche`}
                >
                  <img
                    src={getPosterUrl(media)}
                    alt={media.title}
                    onError={(event) => {
                      event.currentTarget.onerror = null;
                      event.currentTarget.src = '/steldra-poster-placeholder.svg';
                    }}
                  />
                  <span>{media.title}</span>
                </button>
              ))}

              {filteredUnranked.length === 0 && (
                <p data-steldra-ui="emptyLibrary" className={styles.emptyLibrary}>Aucune œuvre ne correspond à cette recherche.</p>
              )}
            </div>
          </div>
        </section>

        {savedMessage && <p data-steldra-ui="savedMessage" className={styles.savedMessage}>{savedMessage}</p>}

        <section ref={tierListRef} data-steldra-ui="tierListExport" className={styles.tierListExport}>
          <div data-steldra-ui="tierHeader" className={styles.tierHeader}>
            <div data-steldra-ui="tierTitleWrap" className={styles.tierTitleWrap}>
              <span data-steldra-ui="tierTitleIcon" className={styles.tierTitleIcon}>✎</span>
              <input
                data-steldra-ui="titleInput" className={styles.titleInput}
                value={title}
                onChange={(event) => setTitle(event.target.value)}
                aria-label="Titre de la tier list"
              />
            </div>

            <div data-steldra-ui="headerActions" className={styles.headerActions} data-html2canvas-ignore="true">
              <button type="button" data-steldra-ui="secondaryButton" className={styles.secondaryButton} onClick={resetTierList}>
                ↻ Réinitialiser
              </button>
              <button type="button" data-steldra-ui="primaryButton" className={styles.primaryButton} onClick={saveTierList}>
                ▣ Enregistrer
              </button>
              <button type="button" data-steldra-ui="primaryButton" className={styles.primaryButton} onClick={downloadTierList}>
                ↓ Télécharger
              </button>
            </div>
          </div>

          <nav data-steldra-ui="mobileTierNav" className={styles.mobileTierNav} aria-label="Accès rapide aux rangs" data-html2canvas-ignore="true">
            {rows.map((row) => (
              <button key={row.id} type="button" onClick={() => scrollToRow(row.id)}>
                {row.title || row.label}
                <span>{row.media.filter((media) => isCinemaType(media.type)).length}</span>
              </button>
            ))}
          </nav>

          <div data-steldra-ui="rows" className={styles.rows}>
            {rows.map((row, rowIndex) => (
              <div
                key={row.id}
                id={`tier-row-${row.id}`}
                data-tier-row-id={row.id}
                data-steldra-ui="tierRow tierRowDragOver tierRowMobileOpen tierRowMobileClosed" className={`${styles.tierRow} ${dragOverRank === row.id ? styles.tierRowDragOver : ''} ${
                  mobileOpenRowIds.has(row.id) ? styles.tierRowMobileOpen : styles.tierRowMobileClosed
                }`}
              >
                <div
                  data-steldra-ui="rankLabel" className={styles.rankLabel}
                  style={{
                    backgroundColor: [
                      '#ff5565', '#ff9a4d', '#ffd84a', '#52d66f', '#4ca9f5', '#a54be7', '#f472b6', '#22d3ee',
                    ][rowIndex % 8],
                  }}
                >
                  <input
                    data-steldra-ui="rankInput" className={styles.rankInput}
                    value={row.label}
                    maxLength={3}
                    onChange={(event) => updateRowLabel(row.id, event.target.value)}
                    aria-label={`Lettre du rang ${row.label}`}
                  />
                </div>

                <div data-steldra-ui="rowContent" className={styles.rowContent}>
                  <div data-steldra-ui="mobileRowHeader" className={styles.mobileRowHeader} data-html2canvas-ignore="true">
                    <input
                      data-steldra-ui="mobileRowTitleInput" className={styles.mobileRowTitleInput}
                      value={row.title}
                      onChange={(event) => updateRowTitle(row.id, event.target.value)}
                      placeholder={`Nom du rang ${row.label}`}
                      aria-label={`Renommer le rang ${row.label}`}
                    />
                    <button
                      type="button"
                      data-steldra-ui="mobileRowToggle" className={styles.mobileRowToggle}
                      onClick={() => toggleMobileRow(row.id)}
                      aria-expanded={mobileOpenRowIds.has(row.id)}
                      aria-controls={`tier-row-media-${row.id}`}
                    >
                      <span data-steldra-ui="mobileRowCount" className={styles.mobileRowCount}>{row.media.filter((media) => isCinemaType(media.type)).length}</span>
                      <span data-steldra-ui="mobileRowChevron" className={styles.mobileRowChevron} aria-hidden="true">
                        {mobileOpenRowIds.has(row.id) ? '⌃' : '⌄'}
                      </span>
                    </button>
                  </div>

                  <div id={`tier-row-media-${row.id}`} data-steldra-ui="rowMedia" className={styles.rowMedia}>
                    {row.media.filter((media) => isCinemaType(media.type)).length === 0 && (
                      <span data-steldra-ui="emptyRowText" className={styles.emptyRowText}>Glissez vos médias ici</span>
                    )}

                    {row.media.filter((media) => isCinemaType(media.type)).map((media, mediaIndex) => (
                      <button
                        key={`${media.type}_${media.id}`}
                        type="button"
                        data-steldra-ui="posterButton posterBeyondMobilePreview" className={`${styles.posterButton} ${
                          mediaIndex >= 15 && !mobileExpandedRowIds.has(row.id)
                            ? styles.posterBeyondMobilePreview
                            : ''
                        }`}
                        onPointerDown={(event) => handlePointerDown(event, media)}
                        onPointerMove={handlePointerMove}
                        onPointerUp={handlePointerUp}
                        onPointerCancel={handlePointerCancel}
                        onClick={(event) => {
                          if (suppressClickRef.current) {
                            event.preventDefault();
                            return;
                          }
                          openMedia(media);
                        }}
                        title={`${media.title} — ouvrir la fiche`}
                      >
                        <img
                          src={getPosterUrl(media)}
                          alt={media.title}
                          data-steldra-ui="poster" className={styles.poster}
                          onError={(event) => {
                            event.currentTarget.onerror = null;
                            event.currentTarget.src = '/steldra-poster-placeholder.svg';
                          }}
                        />
                      </button>
                    ))}
                  </div>

                  {mobileOpenRowIds.has(row.id) && row.media.filter((media) => isCinemaType(media.type)).length > 15 && (
                    <button
                      type="button"
                      data-steldra-ui="mobileShowMoreButton" className={styles.mobileShowMoreButton}
                      onClick={() => toggleMobileRowExpansion(row.id)}
                      data-html2canvas-ignore="true"
                    >
                      {mobileExpandedRowIds.has(row.id)
                        ? 'Réduire'
                        : `Voir les ${row.media.filter((media) => isCinemaType(media.type)).length - 15} autres`}
                      <span aria-hidden="true">{mobileExpandedRowIds.has(row.id) ? ' ↑' : ' ↓'}</span>
                    </button>
                  )}

                  <div data-steldra-ui="rowEditControls" className={styles.rowEditControls}>
                    <input
                      data-steldra-ui="rowTitleInput" className={styles.rowTitleInput}
                      value={row.title}
                      onChange={(event) => updateRowTitle(row.id, event.target.value)}
                      placeholder="Nom du rang"
                      aria-label={`Nom du rang ${row.label}`}
                    />
                    <button
                      type="button"
                      data-steldra-ui="deleteRowButton" className={styles.deleteRowButton}
                      onClick={() => deleteRow(row.id)}
                      data-html2canvas-ignore="true"
                      aria-label={`Supprimer le rang ${row.label}`}
                      title="Supprimer ce rang"
                    >
                      ×
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <button type="button" data-steldra-ui="addRowButton" className={styles.addRowButton} onClick={addRow} data-html2canvas-ignore="true">
            + Ajouter un rang
          </button>

          <p data-steldra-ui="signature" className={styles.signature}>Créé avec Steldra</p>
        </section>

        <button
          type="button"
          data-steldra-ui="mobileBackToTop" className={styles.mobileBackToTop}
          onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
          aria-label="Revenir en haut de la page"
          title="Revenir en haut"
        >
          ↑
        </button>

        <section data-steldra-ui="savedTierListsSection" className={styles.savedTierListsSection}>
          <div data-steldra-ui="savedHeader" className={styles.savedHeader}>
            <div data-steldra-ui="savedTitleWrap" className={styles.savedTitleWrap}>
              <span data-steldra-ui="savedTitleIcon" className={styles.savedTitleIcon}>▯</span>
              <h2>Mes Tier Lists sauvegardées</h2>
            </div>
            <span data-steldra-ui="mediaCount" className={styles.mediaCount}>
              {savedTierLists.length} sauvegarde{savedTierLists.length > 1 ? 's' : ''}
            </span>
          </div>

          {savedTierLists.length === 0 ? (
            <p data-steldra-ui="emptySavedTierLists" className={styles.emptySavedTierLists}>
              Tes Tier Lists enregistrées ou téléchargées apparaîtront ici.
            </p>
          ) : (
            <div data-steldra-ui="savedTierListsGrid" className={styles.savedTierListsGrid}>
              {savedTierLists.map((saved) => {
                const rankedCount = saved.rows.reduce((total, row) => total + row.media.filter((media) => isCinemaType(media.type)).length, 0);
                const previewMedia = saved.rows.flatMap((row) => row.media).filter((media) => isCinemaType(media.type)).slice(0, 7);
                const date = new Intl.DateTimeFormat('fr-FR', {
                  day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit',
                }).format(new Date(saved.updatedAt));

                return (
                  <article
                    key={saved.id}
                    data-steldra-ui="savedTierListCard savedTierListCardActive" className={`${styles.savedTierListCard} ${activeSavedId === saved.id ? styles.savedTierListCardActive : ''}`}
                  >
                    <div data-steldra-ui="savedPreview" className={styles.savedPreview}>
                      {previewMedia.length > 0 ? previewMedia.map((media) => (
                        <img key={`${media.type}_${media.id}`} src={getPosterUrl(media)} alt="" />
                      )) : <span>TL</span>}
                    </div>

                    <div data-steldra-ui="savedInfo" className={styles.savedInfo}>
                      <h3>{saved.title || 'Tier list sans titre'}</h3>
                      <p>Modifiée le {date} · {rankedCount} média{rankedCount > 1 ? 's' : ''}</p>
                    </div>

                    <div data-steldra-ui="savedTierListActions" className={styles.savedTierListActions}>
                      <button type="button" data-steldra-ui="primaryButton" className={styles.primaryButton} onClick={() => editSavedTierList(saved)}>
                        ✎ Modifier
                      </button>
                      <button type="button" data-steldra-ui="secondaryButton" className={styles.secondaryButton} onClick={() => downloadSavedTierList(saved)}>
                        ↓ Télécharger
                      </button>
                      <button type="button" data-steldra-ui="dangerButton" className={styles.dangerButton} onClick={() => deleteSavedTierList(saved)} aria-label="Supprimer">
                        ♙
                      </button>
                    </div>
                  </article>
                );
              })}
            </div>
          )}

          <p data-steldra-ui="storageNote cloudSyncNote" className={`${styles.storageNote} ${styles.cloudSyncNote}`}>
            {cloudSyncStatus === 'ready' && '☁ Tier lists synchronisées sur tous vos appareils.'}
            {cloudSyncStatus === 'loading' && '☁ Synchronisation en cours…'}
            {cloudSyncStatus === 'offline' && 'ⓘ Sauvegarde locale active. Connectez-vous pour synchroniser vos appareils.'}
            {cloudSyncStatus === 'setup-required' && '⚠ Synchronisation à activer dans Supabase avec le fichier SQL fourni.'}
          </p>
        </section>
      </main>
    </>
  );
}
